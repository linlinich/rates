//
//  ViewController.swift
//  MyFirstProgect
//
//  Created by Ангелина on 15.06.2020.
//  Copyright © 2020 Ангелина. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var Label: UILabel!
    
    @IBOutlet weak var summ: UITextField!
    
    
    @IBAction func dollars(_ sender: Any) {
        exchangingRates.text = "\((Int(summ.text!)!) * 74)"+" P"
    }
    
    
    @IBAction func rubles(_ sender: Any) {
        exchangingRates.text = "\(74 / (Double(summ.text!)!))"+" $"
    }
    
    
    @IBOutlet weak var exchangingRates: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

